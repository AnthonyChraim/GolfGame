/*
 * Assignment 1 
 * Written by: Anthony Chraim 40091014
 * For COMP 248 Section W - Winter 2019
 */

//This program was made by me, Anthony Chraim, on February 2nd 2019.
//Its purpose it to print out the desired output using the escape sequences with the backslash (\)

//Start of the program

public class Question1 {

	public static void main(String[] args) {

//Since we used a single println, I used line breaks to cut the String for more clarity
	
		System.out.println("Welcome to my First Java Program!\n"+
							"\n"+
							"A \"quoted\" String is \n"+
							"\'much\' better if you learn \n"+
							"the rules of \"escape sequences.\" \n"+
							"Also, \"\" represents an empty String.\n"+
							"Don\'t forget: use \\\" instead of \" !\n"+
							"\'\' is not the same as \"\n"
							+ "\n"+
							"All Done!!!!");
		 
//This is the end of the program
	
	}

}
