/*
 * Assignment 1 
 * Written by: Anthony Chraim 40091014
 * For COMP 248 Section W - Winter 2019
 */

//This program was made by me, Anthony Chraim, on February 2nd 2019.
//Its purpose is to output the day, month, season and a message when given a valid date by the user


//Start of the program
import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		


		Scanner keyboard = new Scanner(System.in);
		int month, day;
		
		System.out.println("Enter month and day as mm dd: ");

		
		month = keyboard.nextInt();					//First integer inputed by the user will be the month
		day = keyboard.nextInt();					//Second integer inputed by the user will be the day
		String season = getSeason(month, day);		//The getSeason method returns the season to the "season" String
		String message = getMessage(season);		//The getMessage method returns a message depending on the season to the "message" String
		String suffix = getSuffix(month);			//The getSuffix method returns the right suffix depending on the month to the "suffix" String
		
		
		
		System.out.println("The " + day + " of the " + month + suffix + " month falls in " + season + ". " + message);

		keyboard.close();
		 
	}
	

//Returning the right suffix
//We do not need to return an error if the month entered does not exist since the user will only enter valid dates
private static String getSuffix(int month) {
		
		if (month == 1)
			return "st";
		else if (month == 2)
			return "nd";
		else if (month ==3)
			return "rd";
		else
			return "th";
		
		
				}

//Returning the right season using cases and conditionnal operator
private static String getSeason(int month, int day) {

	switch(month) {
	
	case 1: case 2:
		return "winter";
	case 3: 
		return (day >= 21) ? "spring" : "winter"; 
	case 4: case 5:
		return "spring";
	case 6:
		return (day >= 21) ? "summer" : "spring";
	case 7: case 8:
		return "summer";
	case 9:
		return (day >= 21) ? "fall" : "summer";
	case 10: case 11:
		return "fall";
	case 12:
		return (day >= 21) ? "winter" : "fall";
					
		
		
		
	}
	return null;
	
	}

//Returning a unique message depending on the season
//again no need for error return since only valid dates will be inputed
private static String getMessage(String season) {
		
		if (season == "winter")
			return "It is old outside.";
		else if (season == "fall")
			return "I love fall!";
		else if (season == "summer")
			return "It is hot outside.";
		else
			return "The flowers will be out soon.";
		
	}

	
//End of the program
	
		
		
		
	}


